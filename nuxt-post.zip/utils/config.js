const config = {
  host: 'http://127.0.0.1:3333',
  keys: {
    token: 'ap.login.token'
  }
}

export default config
